const DB_NAME = 'music-player-cache';
const STORE_NAME = 'metadata-cache';
const DB_VERSION = 1;

let db = null;

const openDB = () => {
    return new Promise((resolve, reject) => {
        if (db) {
            return resolve(db);
        }

        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onerror = () => {
            console.error('IndexedDB error:', request.error);
            reject('Error opening DB');
        };

        request.onsuccess = () => {
            db = request.result;
            resolve(db);
        };

        request.onupgradeneeded = (event) => {
            const dbInstance = event.target.result;
            if (!dbInstance.objectStoreNames.contains(STORE_NAME)) {
                dbInstance.createObjectStore(STORE_NAME, { keyPath: 'id' });
            }
        };
    });
};

export const get = async (id) => {
    const dbInstance = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = dbInstance.transaction(STORE_NAME, 'readonly');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.get(id);

        request.onsuccess = () => {
            if (request.result) {
                resolve(request.result.metadata);
            } else {
                resolve(undefined);
            }
        };

        request.onerror = () => {
            console.error('Error getting data from IndexedDB:', request.error);
            reject('Error getting data');
        };
    });
};

export const set = async (id, metadata) => {
    const dbInstance = await openDB();
    return new Promise((resolve, reject) => {
        const transaction = dbInstance.transaction(STORE_NAME, 'readwrite');
        const store = transaction.objectStore(STORE_NAME);
        const request = store.put({ id, metadata });

        request.onsuccess = () => {
            resolve();
        };

        request.onerror = () => {
            console.error('Error setting data in IndexedDB:', request.error);
            reject('Error setting data');
        };
    });
};
