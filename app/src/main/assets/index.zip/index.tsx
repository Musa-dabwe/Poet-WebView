import * as db from './db.js';

// Type Definitions
interface Track {
    id: number;
    title: string;
    artist: string;
    albumArtUrl: string;
    audioSrc: string;
    audioElement: HTMLAudioElement;
}

// State
let playlist: Track[] = [];
let currentTrackIndex = 0;
let isPlaying = false;
let repeatMode = 'playlist'; // 'off', 'playlist', 'one'

// DOM Elements
const emptyView = document.getElementById('empty-view') as HTMLElement;
const playerView = document.getElementById('player-view') as HTMLElement;
const fileInput = document.getElementById('file-input') as HTMLInputElement;
const addMusicButton = document.getElementById('add-music-button') as HTMLButtonElement;
const addMoreButton = document.getElementById('add-more-button') as HTMLButtonElement;
const albumArt = document.getElementById('album-art') as HTMLImageElement;
const trackTitle = document.getElementById('track-title') as HTMLElement;
const trackArtist = document.getElementById('track-artist') as HTMLElement;
const currentTimeEl = document.getElementById('current-time') as HTMLElement;
const trackDurationEl = document.getElementById('track-duration') as HTMLElement;
const progressBar = document.getElementById('progress-bar') as HTMLInputElement;
const progressBarFg = document.getElementById('progress-bar-fg') as HTMLElement;
const playPauseButton = document.getElementById('play-pause-button') as HTMLButtonElement;
const playIcon = document.getElementById('play-icon') as HTMLElement;
const pauseIcon = document.getElementById('pause-icon') as HTMLElement;
const prevButton = document.getElementById('prev-button') as HTMLButtonElement;
const nextButton = document.getElementById('next-button') as HTMLButtonElement;
const skipBackwardButton = document.getElementById('skip-backward-button') as HTMLButtonElement;
const skipForwardButton = document.getElementById('skip-forward-button') as HTMLButtonElement;
const repeatButton = document.getElementById('repeat-button') as HTMLButtonElement;
const trackListEl = document.getElementById('track-list') as HTMLUListElement;
const audioContainer = document.getElementById('audio-container') as HTMLElement;

const currentTrack = (): Track | undefined => playlist[currentTrackIndex];

// Utility Functions
const formatTime = (seconds: number): string => {
    if (isNaN(seconds) || seconds < 0) return '00:00';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
};

const fileToDataUrl = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

// Render Functions
const render = () => {
    if (playlist.length === 0) {
        emptyView.classList.remove('hidden');
        playerView.classList.add('hidden');
    } else {
        emptyView.classList.add('hidden');
        playerView.classList.remove('hidden');
        renderCurrentTrackInfo();
        renderPlaylist();
    }
    renderPlayPauseButton();
    renderRepeatButton();
};

const renderCurrentTrackInfo = () => {
    const track = currentTrack();
    if (!track) return;
    albumArt.src = track.albumArtUrl;
    albumArt.alt = `${track.title} album art`;
    trackTitle.textContent = track.title;
    trackArtist.textContent = track.artist;

    if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
            title: track.title,
            artist: track.artist,
            artwork: [{ src: track.albumArtUrl, sizes: '512x512', type: 'image/jpeg' }]
        });
    }
};

const renderPlaylist = () => {
    trackListEl.innerHTML = '';
    const track = currentTrack();
    playlist.forEach((trackItem) => {
        const isActive = trackItem.id === track?.id;
        const li = document.createElement('li');
        li.className = `group flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-all duration-300 ${isActive ? 'bg-cyan-500/20' : 'hover:bg-slate-700/50'}`;
        li.dataset.trackId = trackItem.id.toString();
        
        li.innerHTML = `
            <img src="${trackItem.albumArtUrl}" alt="${trackItem.title}" class="w-10 h-10 rounded-md" />
            <div class="flex-grow">
                <p class="font-semibold ${isActive ? 'text-cyan-400' : 'text-white'}">${trackItem.title}</p>
                <p class="text-sm text-slate-400">${trackItem.artist}</p>
            </div>
            <div class="flex items-center space-x-2 shrink-0">
                ${(isActive && !isPlaying) ? `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5 text-cyan-400"><path fill-rule="evenodd" d="M4.5 5.653c0-1.426 1.529-2.33 2.779-1.643l11.54 6.647c1.295.742 1.295 2.545 0 3.286L7.279 20.99c-1.25.72-2.779-.217-2.779-1.643V5.653z" clip-rule="evenodd" /></svg>` : ''}
                <button data-remove-id="${trackItem.id}" class="remove-track-button text-slate-500 hover:text-white transition-opacity duration-200 ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}" aria-label="Remove ${trackItem.title} from playlist">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="w-5 h-5 pointer-events-none" aria-hidden="true"><path fill-rule="evenodd" d="M5.47 5.47a.75.75 0 011.06 0L12 10.94l5.47-5.47a.75.75 0 111.06 1.06L13.06 12l5.47 5.47a.75.75 0 11-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 01-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 010-1.06z" clip-rule="evenodd" /></svg>
                </button>
            </div>
        `;
        trackListEl.appendChild(li);
    });
};


const renderPlayPauseButton = () => {
    if (isPlaying) {
        playIcon.classList.add('hidden');
        pauseIcon.classList.remove('hidden');
        playPauseButton.setAttribute('aria-label', 'Pause');
    } else {
        playIcon.classList.remove('hidden');
        pauseIcon.classList.add('hidden');
        playPauseButton.setAttribute('aria-label', 'Play');
    }
    if ('mediaSession' in navigator) {
        navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
    }
};

const renderRepeatButton = () => {
    let text = 'Repeat';
    if (repeatMode === 'playlist') text = 'Repeat On';
    if (repeatMode === 'one') text = 'Repeat 1';
    repeatButton.textContent = text;
    repeatButton.setAttribute('aria-label', `Current repeat mode: ${repeatMode}`);
};


// Player Logic
const playAudio = () => {
    const track = currentTrack();
    if (!track || !track.audioElement) return;

    // Pause all other tracks
    playlist.forEach(t => {
        if (t.id !== track.id && t.audioElement) {
            t.audioElement.pause();
            t.audioElement.currentTime = 0;
        }
    });

    track.audioElement.play().catch(error => console.error("Error playing audio:", error));
    setIsPlaying(true);
};

const pauseAudio = () => {
    const track = currentTrack();
    if (track && track.audioElement) {
        track.audioElement.pause();
    }
    setIsPlaying(false);
};

const setIsPlaying = (playing: boolean) => {
    isPlaying = playing;
    renderPlayPauseButton();
    renderPlaylist();
};

const togglePlayPause = () => {
    if (playlist.length === 0) return;
    isPlaying ? pauseAudio() : playAudio();
};

const goToNextTrack = () => {
    if (playlist.length === 0) return;
    const newIndex = (currentTrackIndex + 1) % playlist.length;
    changeTrack(newIndex);
};

const goToPrevTrack = () => {
    if (playlist.length === 0) return;
    const newIndex = (currentTrackIndex - 1 + playlist.length) % playlist.length;
    changeTrack(newIndex);
};

const changeTrack = (index: number) => {
    pauseAudio();
    currentTrackIndex = index;
    render();
    if (isPlaying) {
        setTimeout(playAudio, 50);
    }
};

const handleTrackEnd = () => {
    const isLastTrack = currentTrackIndex === playlist.length - 1;

    if (repeatMode === 'one') {
        const track = currentTrack();
        if (track && track.audioElement) {
            track.audioElement.currentTime = 0;
            playAudio();
        }
    } else if (repeatMode === 'playlist') {
        goToNextTrack();
    } else { // repeatMode === 'off'
        if (isLastTrack) {
            pauseAudio();
        } else {
            goToNextTrack();
        }
    }
};

// Event Handlers
const handleFileChange = async (event: Event) => {
    const input = event.target as HTMLInputElement;
    const files = input.files;
    if (!files || files.length === 0) return;

    const extractMetadata = (file: File): Promise<{title: string, artist: string, albumArtBlob?: Blob}> => new Promise(resolve => {
        (window as any).jsmediatags.read(file, {
            onSuccess: (tag: any) => {
                const { title, artist, picture } = tag.tags;
                let albumArtBlob;
                if (picture) {
                    albumArtBlob = new Blob([new Uint8Array(picture.data)], { type: picture.format });
                }
                resolve({
                    title: title || file.name.replace(/\.[^/.]+$/, ""),
                    artist: artist || "Unknown Artist",
                    albumArtBlob,
                });
            },
            onError: () => {
                resolve({ title: file.name.replace(/\.[^/.]+$/, ""), artist: "Unknown Artist" });
            },
        });
    });

    const audioFiles = Array.from(files).filter(file => file.type.startsWith('audio/'));
    
    for (const file of audioFiles) {
        const cacheKey = `${file.name}-${file.size}-${file.lastModified}`;
        let metadata: {title: string, artist: string, albumArtBlob?: Blob} | undefined = await db.get(cacheKey);

        if (!metadata) {
            metadata = await extractMetadata(file);
            await db.set(cacheKey, metadata);
        }

        const albumArtUrl = metadata.albumArtBlob ? URL.createObjectURL(metadata.albumArtBlob) : `https://picsum.photos/seed/${encodeURIComponent(metadata.title)}/400`;
        const audioSrc = await fileToDataUrl(file);
        
        const audioElement = new Audio(audioSrc);
        audioElement.addEventListener('timeupdate', () => updateProgress(audioElement));
        audioElement.addEventListener('loadedmetadata', () => updateProgress(audioElement));
        audioElement.addEventListener('ended', handleTrackEnd);
        audioContainer.appendChild(audioElement);

        playlist.push({
            id: Date.now() + Math.random(),
            title: metadata.title,
            artist: metadata.artist,
            albumArtUrl,
            audioSrc,
            audioElement,
        });
    }

    if (audioFiles.length > 0) {
        const wasEmpty = playerView.classList.contains('hidden');
        render();
        if (wasEmpty) {
           playAudio();
        }
    }

    input.value = ''; // Reset file input
};

const updateProgress = (audioElement: HTMLAudioElement) => {
    if (audioElement !== currentTrack()?.audioElement) return;

    const { currentTime, duration } = audioElement;
    
    currentTimeEl.textContent = formatTime(currentTime);
    if (isFinite(duration)) {
        trackDurationEl.textContent = formatTime(duration);
        progressBar.max = duration.toString();
    } else {
        trackDurationEl.textContent = '00:00';
        progressBar.max = '0';
    }
    
    progressBar.value = currentTime.toString();
    const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;
    progressBarFg.style.width = `${progressPercentage}%`;
};

const handleSeek = (event: Event) => {
    const time = Number((event.target as HTMLInputElement).value);
    const track = currentTrack();
    if (track && track.audioElement) {
        track.audioElement.currentTime = time;
        updateProgress(track.audioElement);
    }
};

const handleSkipForward = () => {
    const track = currentTrack();
    if (track && track.audioElement) {
        track.audioElement.currentTime = Math.min(track.audioElement.currentTime + 5, track.audioElement.duration);
    }
};

const handleSkipBackward = () => {
    const track = currentTrack();
    if (track && track.audioElement) {
        track.audioElement.currentTime = Math.max(track.audioElement.currentTime - 5, 0);
    }
};

const toggleRepeatMode = () => {
    if (repeatMode === 'off') repeatMode = 'playlist';
    else if (repeatMode === 'playlist') repeatMode = 'one';
    else repeatMode = 'off';
    renderRepeatButton();
};

const triggerFileInput = () => fileInput.click();

const handlePlaylistClick = (event: MouseEvent) => {
    const target = event.target as HTMLElement;
    const li = target.closest('li[data-track-id]');
    const removeButton = target.closest('.remove-track-button');
    
    if (removeButton) {
        const trackIdToRemove = Number((removeButton as HTMLElement).dataset.removeId);
        handleRemoveTrack(trackIdToRemove);
        return;
    }

    if (li) {
        // Fix: Cast 'li' to HTMLElement to access the 'dataset' property.
        const trackId = Number((li as HTMLElement).dataset.trackId);
        const trackIndex = playlist.findIndex(t => t.id === trackId);
        if (trackIndex !== -1) {
            changeTrack(trackIndex);
            playAudio();
        }
    }
};

const handleRemoveTrack = (trackIdToRemove: number) => {
    const trackToRemoveIndex = playlist.findIndex(t => t.id === trackIdToRemove);
    if (trackToRemoveIndex === -1) return;

    const trackToRemove = playlist[trackToRemoveIndex];
    
    // Cleanup resources
    if (trackToRemove.audioSrc.startsWith('blob:')) URL.revokeObjectURL(trackToRemove.audioSrc);
    if (trackToRemove.albumArtUrl.startsWith('blob:')) URL.revokeObjectURL(trackToRemove.albumArtUrl);
    if (trackToRemove.audioElement) {
        trackToRemove.audioElement.pause();
        trackToRemove.audioElement.remove();
    }
    
    const wasCurrentlyPlayingTrack = trackToRemoveIndex === currentTrackIndex;

    // Remove from playlist
    playlist.splice(trackToRemoveIndex, 1);
    
    if (playlist.length === 0) {
        pauseAudio();
        currentTrackIndex = 0;
        render();
        return;
    }

    if (wasCurrentlyPlayingTrack) {
        const newIndex = trackToRemoveIndex >= playlist.length ? 0 : trackToRemoveIndex;
        changeTrack(newIndex);
    } else {
        if (trackToRemoveIndex < currentTrackIndex) {
            currentTrackIndex--;
        }
        render();
    }
};

const setupEventListeners = () => {
    addMusicButton.addEventListener('click', triggerFileInput);
    addMoreButton.addEventListener('click', triggerFileInput);
    fileInput.addEventListener('change', handleFileChange);
    
    playPauseButton.addEventListener('click', togglePlayPause);
    nextButton.addEventListener('click', goToNextTrack);
    prevButton.addEventListener('click', goToPrevTrack);
    
    skipForwardButton.addEventListener('click', handleSkipForward);
    skipBackwardButton.addEventListener('click', handleSkipBackward);
    
    progressBar.addEventListener('input', handleSeek);
    repeatButton.addEventListener('click', toggleRepeatMode);
    
    trackListEl.addEventListener('click', handlePlaylistClick as EventListener);

    // Media Session API
    if ('mediaSession' in navigator) {
        navigator.mediaSession.setActionHandler('play', togglePlayPause);
        navigator.mediaSession.setActionHandler('pause', togglePlayPause);
        navigator.mediaSession.setActionHandler('previoustrack', goToPrevTrack);
        navigator.mediaSession.setActionHandler('nexttrack', goToNextTrack);
    }

    // Cleanup on exit
    window.addEventListener('beforeunload', () => {
        playlist.forEach(track => {
            if (track.audioSrc.startsWith('blob:')) URL.revokeObjectURL(track.audioSrc);
            if (track.albumArtUrl.startsWith('blob:')) URL.revokeObjectURL(track.albumArtUrl);
        });
    });
};

// Initialization
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    render();
});
